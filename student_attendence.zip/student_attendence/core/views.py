from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from core.verify import authentication
from django.contrib import messages
from .models import *
from .forms import *
import face_recognition
import cv2
import numpy as np
import winsound
from django.db.models import Q
from playsound import playsound
import os
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control


def log_in(request):
    if request.method == "POST":
        # return HttpResponse("This is Home page")  
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username = username, password = password)

        if user is not None:
            login(request, user)
            messages.success(request, "Log In Successful...!")
            return redirect("dashboard")
        else:
            messages.error(request, "Invalid User...!")
            return redirect("log_in")
    return render(request, 'core/log_in.html')

def register(request):
    if request.method == "POST":
        fname = request.POST['fname']
        lname = request.POST['lname']
        username = request.POST['username']
        password = request.POST['password']
        password1 = request.POST['password1']
        # print(fname, contact_no, ussername)
        verify = authentication(fname, lname, password, password1)
        if verify == "success":
            user = User.objects.create_user(username, password, password1)          #create_user
            user.first_name = fname
            user.last_name = lname
            user.save()
            messages.success(request, "Your Account has been Created.")
            return redirect("/")
            
        else:
            messages.error(request, verify)
            return redirect("register")
    return render(request, 'core/register.html')


def index(request):
    context = {
    }
    return render(request, 'core/index.html', context)

@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def dashboard(request):
    context = {
        'fname': request.user.first_name, 
        'lname': request.user.last_name, 
    }
    return render(request, 'core/dashboard.html', context)


@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def scan(request):

    video_capture = cv2.VideoCapture(0)

    while True:

        ret, frame = video_capture.read()

        cv2.imshow('Video', frame)

        if cv2.waitKey(1) & 0xFF==ord("q"):
            break

    video_capture.release()
    cv2.destroyAllWindows()
    return HttpResponse('scaner closed')

@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def profiles(request):
    context = {
        'fname': request.user.first_name, 
        'lname': request.user.last_name, 
    }
    return render(request, 'core/profiles.html', context)



@login_required(login_url="log_in")
@cache_control(no_cache = True, must_revalidate = True, no_store = True)
def log_out(request):
    logout(request)
    messages.success(request, "Log out Successfuly...!")
    return redirect("index")