from django.urls import path,include
from .views import *


urlpatterns = [
    path('', index, name= 'index'),
    path('dashboard', dashboard, name= 'dashboard'),
    path('log_in', log_in, name= 'log_in'),
    path('register', register, name= 'register'),
    path('scan/',scan,name='scan'),
    path('profiles/', profiles, name= 'profiles'),
    path('log_out', log_out, name= 'log_out'),


]
